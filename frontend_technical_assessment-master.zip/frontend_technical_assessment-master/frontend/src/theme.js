// src/Theme.js

export const theme = {
    background: '#f0f0f0',
    text: '#333',
    primary: '#8743ff',
    secondary: '#4316db',
  };
  
  export default theme;
  